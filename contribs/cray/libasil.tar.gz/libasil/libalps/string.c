#define _ISOC99_SOURCE	/* for LLONG_{MIN,MAX} */
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <errno.h>

/**
 * atou64 - Convert string into u64
 * Returns 1 if ok, < 0 on error.
 */
int atou64(const char *str, uint64_t *val)
{
	char *endptr;

	errno = 0;				/* strtol() manpage */
	*val  = strtoull(str, &endptr, 0);
	if ((errno == ERANGE && *val == ULLONG_MAX) ||
	    (errno != 0 && *val == 0)	||	/* other error */
	    endptr == str		||	/* no digits */
	    *endptr != '\0')			/* junk at end */
		return -1;
	return 1;
}

int atou32(const char *str, uint32_t *val)
{
	uint64_t tmp;

	if (!atou64(str, &tmp) || tmp > 0xFFFFffffUL)
		return -1;
	*val = tmp;
	return 1;
}

/**
 * Write/append to a buffer, checking the length.
 * @buf:    the buffer to write to
 * @offset: current buffer offset
 * @max:    total length of @buf
 * @fmt:    as in snprintf(3)
 * Return true if ok, false if truncated.
 */
bool check_snprintf(char *buf, size_t *offset, size_t max, const char *fmt, ...)
{
	va_list ap;
	int written, size = max - *offset;

	if (size < 1)
		return false;

	va_start(ap, fmt);
	written = vsnprintf(buf + *offset, size, fmt, ap);
	va_end(ap);

	if (written < 0 || written >= size)
		return false;
	*offset += written;
	return true;
}
