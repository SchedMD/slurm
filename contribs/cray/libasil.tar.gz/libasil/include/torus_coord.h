/*
 * Encoding of torus coordinates in base-36
 */
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <assert.h>

/*
 * Conversion constants
 */
#define TORUS_MAX_DIM          3
#define TORUS_MAX_COORD_BITS   5
/* Maximum coordinate axis value supported by current implementation */
#define TORUS_MAX_COORD        ((1UL << TORUS_MAX_COORD_BITS) - 1)

/** Base-36 encoding of @tc */
static inline char enc_toruscoord(uint8_t tc)
{
	assert(tc <= TORUS_MAX_COORD);
	return tc + (tc < 10 ? '0' : 'A' - 10);
}

/** Decode base-36 encoded coordinate value. */
static inline int dec_toruscoord(char asciicoord)
{
	if (0 <= asciicoord && asciicoord <= '9')
		return asciicoord - '0';
	if ('A' <= asciicoord && asciicoord <= ('A' - 10 + TORUS_MAX_COORD))
		return asciicoord - 'A' + 10;
	if ('a' <= asciicoord && asciicoord <= ('a' - 10 + TORUS_MAX_COORD))
		return asciicoord - 'a' + 10;
	return -1;
}

/**
 * struct torus_coord - Node position within the torus
 */
struct torus_coord {
	int x;
	int y;
	int z;
};

/** Encode @tc into 3D coordinate string */
static inline const char *toruscoord2str(const struct torus_coord *tc)
{
	static char coords[4];	/* 3D + '\0' */

	snprintf(coords, sizeof(coords), "%c%c%c", enc_toruscoord(tc->x),
		 enc_toruscoord(tc->y), enc_toruscoord(tc->z));
	return coords;
}

/** Decode 3D-coordinate string @str into @tc */
static inline bool str2toruscoord(const char *str, struct torus_coord *tc)
{
	size_t len;

	if (str == NULL)
		return false;

	len = strlen(str);
	if (len < 3)
		return false;

	tc->x = dec_toruscoord(str[len-3]);
	tc->y = dec_toruscoord(str[len-2]);
	tc->z = dec_toruscoord(str[len-1]);

	return tc->x >= 0 && tc->y >= 0 && tc->z >= 0;
}
