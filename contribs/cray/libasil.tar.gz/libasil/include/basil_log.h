/*
 * Conditionally compiled error and logging routines for ALPS
 */
#ifndef __BASIL_LOG_H
#define __BASIL_LOG_H
#include <stdarg.h>
#include <assert.h>
#include <err.h>

#ifdef _LOG_EXTERNAL
extern void info(const char *fmt, ...);
extern void fatal(const char *fmt, ...);
#define alps_warn(fmt,  args...)	info(fmt, ##args)
#define alps_error(fmt, args...)	fatal(fmt, ##args)

#else
static void alps_warn(const char *fmt, ...)
		__attribute__((format(printf, 1, 2)));
static void alps_error(const char *fmt, ...)
		__attribute__((format(printf, 1, 2)));

/** Write formatted error message. */
static inline void alps_warn(const char *fmt, ...)
{
	va_list ap;

	va_start(ap, fmt);
	vwarnx(fmt, ap);
	va_end(ap);
}

/** Write formatted "fatal" error message. */
static inline void alps_error(const char *fmt, ...)
{
	va_list ap;

	va_start(ap, fmt);
	verrx(1, fmt, ap);
	va_end(ap);
}
#endif
#endif /* __BASIL_LOG_H */
