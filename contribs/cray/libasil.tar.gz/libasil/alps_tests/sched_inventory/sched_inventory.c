/*
 * Test program for a "counting" scheduler inventory.
 */
#include "basil_alps.h"

int main(int ac, char **av)
{
	enum basil_version version  = get_basil_version();
	struct basil_inventory *inv = get_sched_inventory(version);

	if (!inv)
		return EXIT_FAILURE;

	printf("Batch avail/total: %u/%u\n",
		inv->batch_avail, inv->batch_total);

	return EXIT_SUCCESS;
}
