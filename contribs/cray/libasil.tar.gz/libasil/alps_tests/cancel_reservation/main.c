/*
 * Implement 'ampgr cancel' functionality
 */
#include "basil_alps.h"

int main(int argc, char **argv)
{
	if (geteuid())
		errx(1, "this program can only be run by root");

	if (argc == 1)
		errx(1, "need one or more ALPS reservation IDs");

	while (--argc) {
		long res_id = atol(*++argv);

		if (basil_release(res_id) < 0)
			warnx("WARNING: could not release reservation #%ld", res_id);
	}

	return EXIT_SUCCESS;
}
