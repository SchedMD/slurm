/*
 * Test program for the MoM MPP Inventory Request
 */
#include "basil_alps.h"

extern const char *mpp_inventory(void);

int main(int ac, char **av)
{
	const char *mpp_string = mpp_inventory();

	if (mpp_string)
		printf("%s\n", mpp_string);

	return mpp_string ? EXIT_SUCCESS : EXIT_FAILURE;
}

