/*
 * Extract node coordinates
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <assert.h>
#include <err.h>
#include <mysql.h>

/**
 * run_query_stmt - Prepare and run a typed statement.
 * @handle:	connected handle
 * @bind:	prepared array of bind parameters
 * 		==> non-NULL 'is_null'/'error' fields are taken to mean that
 * 		    NULL values/errors are not acceptable
 * @query: 	query statement string to execute
 * @columms:	number of expected columns (length of @bind)
 * @do_store:	whether to buffer the entire result set
 *
 * The statement must not contain parameters.
 * Returns executed statement, NULL on error.
 */
static MYSQL_STMT *run_query_stmt(MYSQL *handle,
				  MYSQL_BIND bind[],
				  const char *query,
				  unsigned long columns,
				  bool do_store)
{
	MYSQL_STMT	*stmt;
	MYSQL_RES	*result_metadata;
	unsigned long	ncols;

	if (query == NULL || *query == '\0')
		return NULL;

	/* Initialize statement (fails only if out of memory). */
	stmt = mysql_stmt_init(handle);
	if (stmt == NULL) {
		warnx("can not allocate handle for '%s'", query);
		return NULL;
	}

	/* Prepare statement */
	if (mysql_stmt_prepare(stmt, query, strlen(query))) {
		warnx("can not prepare statement '%s': %s",
			query, mysql_stmt_error(stmt));
		goto stmt_failed;
	}

	/* Verify that the statement expects no parameters */
	if (mysql_stmt_param_count(stmt) != 0) {
		warnx("statement '%s' contains unsupported parameters", query);
		goto stmt_failed;
	}

	/* Fetch result-set meta information */
	result_metadata = mysql_stmt_result_metadata(stmt);
	if (!result_metadata) {
		warnx("can not obtain statement meta information for '%s': %s",
			query, mysql_stmt_error(stmt));
		goto stmt_failed;
	}

	/* Check total column count of query */
	ncols = mysql_num_fields(result_metadata);
	if (ncols != columns) {
		warnx("wrong column count %lu", ncols);
		mysql_free_result(result_metadata);
		goto stmt_failed;
	}

	/* Free the prepared result metadata */
	mysql_free_result(result_metadata);

	/* Execute the statement */
	if (mysql_stmt_execute(stmt)) {
		warnx("failed to execute '%s': %s", query,
			mysql_stmt_error(stmt));
		goto stmt_failed;
	}

	/* Bind result buffers */
	if (mysql_stmt_bind_result(stmt, bind)) {
		warnx("can not bind parameters of '%s': %s", query,
			mysql_stmt_error(stmt));
		goto stmt_failed;
	}

	if (!do_store)
		goto stmt_done;

	/* Buffer all results on the client if enabled */
	if (mysql_stmt_store_result(stmt)) {
		warnx("can not store result for '%s': %s", query,
			mysql_stmt_error(stmt));
		goto stmt_failed;
	}

	/* Validate results */
	while (mysql_stmt_fetch(stmt) == 0) {
		int i;

		for (i = 0; i < columns; i++)
			if (bind[i].error && *bind[i].error)  {
				warnx("result value in column %d truncated: %s",
					i, mysql_stmt_error(stmt));
				goto stmt_failed;
			} else if (bind[i].is_null && *bind[i].is_null) {
				warnx("unexpected NULL result in column %d", i);
				goto stmt_failed;
			}
	}

	/* Seek back to begin of data set */
	mysql_stmt_data_seek(stmt, 0);

stmt_done:
	return stmt;
stmt_failed:
	(void)mysql_stmt_close(stmt);
	return NULL;
}

/*
 * Set @handle to read user/password from configuration file.
 */
int get_options_from_default_conf(MYSQL *handle)
{
	const char *default_conf_paths[] = {
		"/etc/my.cnf",
		"/etc/opt/cray/MySQL/my.cnf",
		NULL
	};
	const char **path;

	for (path = default_conf_paths; *path; path++)
		if (access(*path, R_OK) == 0)
			break;
	if (*path == NULL)
		errx(1, "no readable 'my.cnf' found");
	return  mysql_options(handle, MYSQL_READ_DEFAULT_FILE, *path);
}

int main(int ac, char **av)
{
	/*
	 * Coordinates can be NULL if the blade has been disabled.
	 * In this case, very likely also processor_status != 'up'
	 */
	const char query[] =	"SELECT processor_id, "
				"	cab_position, cab_row, "
				"	cage, slot, cpu, "
				"	x_coord, y_coord, z_coord "
				"FROM  processor "
				"WHERE x_coord IS NOT NULL "
				"AND   y_coord IS NOT NULL "
				"AND   z_coord IS NOT NULL";
	enum query_columns {
			COL_NODE_ID,
			COL_CAB,
			COL_ROW,
			COL_CAGE,
			COL_SLOT,
			COL_CHIP,
			COL_X,
			COL_Y,
			COL_Z,
			COLUMN_COUNT
	};
	MYSQL		*handle;
	MYSQL_BIND	bind[COLUMN_COUNT];
	MYSQL_STMT	*stmt;

	unsigned int	node_id;
	int		col_data[COLUMN_COUNT];
	my_bool		is_null[COLUMN_COUNT];
	my_bool		error[COLUMN_COUNT];

	my_ulonglong	nrows;
	int		rc = -1, i;

	memset(bind, 0, sizeof(bind));
	for (i = 0; i < COLUMN_COUNT; i ++) {
		/*
		 * @buffer:	   address of variable to write into
		 * @buffer_type:   determines which variable type to use
		 * 		   - TINYINT  => MYSQL_TYPE_TINY
		 * 		   - SMALLINT => MYSQL_TYPE_SHORT
		 * 		   - INT      => MYSQL_TYPE_LONG
		 * 		   - BIGINT   => MYSQL_TYPE_LONGLONG
		 * 		   - FLOAT    => MYSQL_TYPE_FLOAT
		 * 		   - DOUBLE   => MYSQL_TYPE_DOUBLE
		 * 		   - VARCHAR
		 * 		     CHAR     => MYSQL_TYPE_STRING
		 * 		     TEXT
		 * @is_unsigned:   whether variable is unsigned
		 * @buffer_length: actual size of the @buffer in bytes
		 * @length:	   actual data length
		 * @is_null:	   indicates that result is NULL
		 * @error:	   to report potential truncation
		 */
		bind[i].buffer_type = MYSQL_TYPE_LONG;
		bind[i].buffer	    = (char *)&col_data[i];
		bind[i].is_null	    = &is_null[i];
		bind[i].error	    = &error[i];
	}

	/* The first column (node_id / processor_id) is the exception */
	bind[COL_NODE_ID].buffer      = (char *)&node_id;
	bind[COL_NODE_ID].is_unsigned = true;

	/* 1. Initialize 'MYSQL' connection handler */
	handle = mysql_init(NULL);

	if (get_options_from_default_conf(handle) != 0) {
		warnx("can not get options from configuration file (%u) - %s",
			mysql_errno(handle), mysql_error(handle));
		goto err;
	}

	/* 2. connect to the server */
	if (mysql_real_connect(handle, "sdb", NULL, NULL, "XTAdmin",
						0, NULL, 0) == NULL) {
		warnx("can not connect (%u) - %s",
			mysql_errno(handle), mysql_error(handle));
		goto err;
	}

	/* 3. launch query as a prepared statement */
	stmt = run_query_stmt(handle, bind, query, COLUMN_COUNT, true);
	if (stmt == NULL)
		goto err;

	/* Fetch all rows (1) */
	nrows = mysql_stmt_affected_rows(stmt);
	if (nrows == (my_ulonglong)-1) {
		/*
		 * NB: This is _not_ an error if last argument to
		 *     run_query_stmt() is 'false', since then the
		 *     number of rows is only known afterwards.
		 */
		warnx("query '%s' returned an error: %s", query,
			mysql_stmt_error(stmt));
		goto err;
	} else if (nrows == 0) {
		warnx("no results retrieved");
	} else {
		warnx("found %llu rows\n", nrows);
	}

	/* Iterate through the entire result set */
	while (mysql_stmt_fetch(stmt) == 0) {
		printf("%6u c%d-%dc%ds%dn%d  %3d %3d %3d\n", node_id,
			col_data[COL_CAB], col_data[COL_ROW],
			col_data[COL_CAGE], col_data[COL_SLOT], col_data[COL_CHIP],
			col_data[COL_X], col_data[COL_Y], col_data[COL_Z]);
	}

	/* Deallocate handle. Errors can be 'server gone away' or 'unknown' */
	if (mysql_stmt_close(stmt)) {
		warnx("error closing statement: %s",
			mysql_stmt_error(stmt));
		goto err;
	}

	rc = 0;
err:
	mysql_close(handle);

	return rc ? EXIT_FAILURE : EXIT_SUCCESS;
}
