#!/bin/bash
lzcat $(dirname $(readlink -f $0))/gele_empty_inventory.xml.lzma
