#!/bin/sh
#
# Generate a fake apbasil inventory
#
cat <<EO_ERR
<?xml version="1.0"?>
<BasilResponse protocol="1.0">
	<ResponseData status="FAILURE" method="RESERVE" error_class="PERMANENT" error_source="BACKEND">
	<Message severity="ERROR">ALPS error: at least one command's user NID list is short</Message>
</ResponseData>
</BasilResponse>
EO_ERR
