/*
 * Parse appinfo information
 */
#include "basil_alps.h"

#include <alps/apInfo.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>

/* Location of ALPS configuration file */
#define ALPS_CONFIGURATION_PATH	"/etc/sysconfig/alps"	/*  FIXME autoconf rule for this path */

/* Configuration variable specifying ALPS shared directory */
#define ALPS_CONF_SHARED	"ALPS_SHARED_DIR_PATH"
#define ALPS_CONF_SHARED_LEN	(sizeof(ALPS_CONF_SHARED) - 1)
/* ALPS appinfo file to access */
#define ALPS_APPINFO_PATH	"appinfo"

/** 
 * Determine configured appinfo path at runtime.
 * Return allocated result, abort on configuration error.
 */
char *basil_get_appinfo_path(void)
{
	const char alps_conf_path[] = ALPS_CONFIGURATION_PATH;
	char alps_line[1024], *p, *path = NULL, *result = NULL;
	FILE *alps_conf;

	if (access(alps_conf_path, F_OK) < 0)
		fatal("no ALPS configuration file '%s'", alps_conf_path);

	alps_conf = fopen(alps_conf_path, "r");
	if (alps_conf == NULL)
		fatal("can not open '%s'", alps_conf_path);

	while (fgets(alps_line, sizeof(alps_line), alps_conf)) {
		p = strchr(alps_line, '#');
		if (p)
			*p = '\0';
		for (p = alps_line; isspace(*p); p++)
			;
		if (strncmp(p, ALPS_CONF_SHARED, ALPS_CONF_SHARED_LEN) == 0) {
			path = p + ALPS_CONF_SHARED_LEN;
			while (*path == '=' || *path == '"' || isspace(*path))
				path++;
			for (p = path; *p && !isspace(*p) && *p != '"'; p++)
				;
			*p = '\0';
			break;
		}
	}
	fclose(alps_conf);
	if (path == NULL)
		fatal("can not determine %s", ALPS_CONF_SHARED);
	if (access(path, F_OK) < 0)
		fatal("can not access %s='%s'", ALPS_CONF_SHARED, path);
	result = malloc(strlen(path) + strlen(ALPS_APPINFO_PATH) + 2);
	if (result == NULL)
		fatal("can not allocate");
	sprintf(result, "%s/%s", path, ALPS_APPINFO_PATH);
	return result;
}

/** 
 * Return 0-terminated array of apids, NULL if no result and on error
 * Code in part taken from openMPI's orte_ras_alps_read_appinfo_file()
 */
/* Maximum number of attempts to read the NFS-shared file */
#define ALPS_APPINFO_MAX_TRIES	3
uint64_t *basil_get_apids_for_resid(uint32_t resid)
{
	uint64_t *apids = NULL;
	return apids;
}

/* Return buffer containing current appinfo (must be freed) or NULL */
uint8_t *basil_get_appinfo(void)
{
	int fd = -1, attempts, n;
	uint8_t *ai_buf	 = NULL;
	char	*ai_path = basil_get_appinfo_path();

	/* Not necessarily an error: shared directory may have been purged */
	if (access(ai_path, F_OK) < 0) {
		error("%s: no appinfo file '%s'", __func__, ai_path);
		goto done;
	}

	for (attempts = 0; ++attempts < ALPS_APPINFO_MAX_TRIES; ) {
		struct stat ai_stat;
		
		fd = open(ai_path, O_RDONLY);
		if (fd  == -1) {
			continue;
		} else if (fstat(fd, &ai_stat) < 0) {
			error("can not stat %s", ai_path);
		} else if (ai_stat.st_size == 0) {
			error("%s is empty", ai_path);
			goto done;
		} else if (ai_stat.st_size < sizeof(appInfoHdr_t)) {
			error("%s is too short", ai_path);
			goto done;
		} else {
			ai_buf = malloc(ai_stat.st_size);
			if (ai_buf == NULL) {
				error("out of memory");
				goto done;
			}
			do {
				n = read(fd, ai_buf, ai_stat.st_size);
			} while (n < 0 && errno == EINTR);
			if (n == ai_stat.st_size)
				break;
		}
		close(fd);
		fd = -1;
		free(ai_buf);
		ai_buf = NULL;
		usleep(attempts * 50000);
	}
	if (ai_buf == NULL && attempts == ALPS_APPINFO_MAX_TRIES)
		error("failed to open '%s'", ai_path);
done:
	if (fd != -1)
		close(fd);
	free(ai_path);
	return ai_buf;
}

#include <grp.h>
#include <pwd.h>
#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))

static const char *_alps_arch(int arch)
{
	static const char *alps_arch[] = {
		"(invalid architecture)",
		"BW",
		"XT"
	};
	return alps_arch[arch < 0 || arch >= ARRAY_SIZE(alps_arch) ? 0 : arch];
}

/* ALPS command details */
void print_cmd_detail(uint8_t *ptr)
{
	cmdDetail_t *det = (cmdDetail_t *)ptr;
	/*
	 *--------------------------------------------------------------
	 * cmdDetail_t
	 *--------------------------------------------------------------
	 * int   width		- number of PEs for this command
	 * int   depth		- processors per PE
	 * int   fixedPerNode	- user set per-node PE count
	 * char  cmd[32]	- a.out name ("BASIL" for reservation)
	 *
	 * int   memory		- per PE memory limit in megabytes
	 * alps_archType_t arch	- architecture type
	 * int   nodeCnt	- number of nodes allocated
	 * int   flags		- command-specific flags (often 0)
	 *
	 * uint16_t pesPerSeg	-S value
	 * uint16_t nodeSegCnt	-sn value
	 * uint32_t segBits	-sl <0-3> - each bit is a segment number
	 * 
	 * uint16_t rvalue	-r value - 0 or 1; maybe bitmask later
	 */
	printf(" -n %d -d %d -N %d %s, %dMB, %s, nodes %d\n",
			det->width, det->depth, det->fixedPerNode,
			det->cmd,
			det->memory,
			_alps_arch(det->arch),
			det->nodeCnt
			);

}

/* ALPS node specific info */
void print_placelist(uint8_t *ptr)
{
	placeList_t	*pl = (placeList_t *)ptr;
	/*
	 *--------------------------------------------------------------
	 * placeList_t
	 *--------------------------------------------------------------
	 * int       cmdIx	- cmdInfo_t entry this PE belongs to
	 * int       nid	- NID this PE is assigned to
	 * short     nodeMap	- XT segment/X2 PE map
	 * uint32_t  procMask	- bitmap of CPUs used
	 */
	printf(" %d", pl->nid);
	//printf("nid[%d] =  %u, map = %d ", pl->cmdIx, pl->nid, pl->nodeMap);
}

void print_apstat(uint8_t *ai_buf)
{
	uint8_t 	*ptr;		/* current position in structure */
	appInfoHdr_t    *ai_hdr;                 /* ALPS header structure          */
	size_t offset;
	int i, j;

	assert(ai_buf != NULL);
	ai_hdr = (appInfoHdr_t *)ai_buf;
	offset = ai_hdr->apStart;		/* offset of first appInfo_t entry */
	/* ai_hdr->apNum is the number of appinfo entries */
	for (i = 0; i < ai_hdr->apNum; i++) {
		appInfo_t *ai_info = (appInfo_t *)(ai_buf + offset);
		struct group *group = getgrgid(ai_info->gid);
		struct passwd *pass = getpwuid(ai_info->uid);
		struct nodespec *ns = NULL;
		/*
		 *--------------------------------------------------------------
		 * appInfo_t
		 *---------------------- GENERAL: ------------------------------
		 * uint      resId	- ALPS reservation ID
    		 * uint64_t  apid	- ALPS application ID
		 * uint64_t  pagg	- ALPS cookie (SGI pagg or shell SID)
		 * uint64_t  flags	- RECFLAG_* flags
		 *                        If RECFLAG_USERNL is set in 'flags',
		 *                        this nid list may not be discarded by
		 *                        recovery for confirm retry.
		 * uid_t     uid	- user UID
		 * int64_t   account	- same as uid or 0
		 * gid_t     gid	- user GID
		 *
		 * pid_t     aprunPid	- PID of aprun (0 if nothing is running)
		 * int       aprunNid	- NID of aprun's login node
		 *
		 * int	     reqType	- most recent request type ALPS_RES_* values
		 * int       fanout	- control tree fanout width
		 *---------------------- OFFSETS: ------------------------------
		 * size_t    cmdDetail	- offset of first cmdDetail_t entry
		 * int       numCmds	- entries in cmdDetail
		 *
		 * size_t    places	- offset of first placeList_t entry
		 * int	     numPlaces	- entries in places
		 *---------------------- TIMES: --------------------------------
		 * int       timeLim
		 * int       slicePri	- time slicing priority
		 * 
		 * time_t    timePlaced
		 * time_t    timeSubmitted
		 * time_t  timeChkptd	- time of latest successful checkpoint
		 * int       conTime	- connect time for context switched apps
		 * time_t    swInTime	- time of last context switch in
		 * time_t    swOutTime	- time of last context switch out
		 *
		 * ---------------- XT_GNI only: -------------------------------
		 * uint16_t  pTag	- 8-bit NTT-unique value used by drivers
		 * uint32_t  cookie	- per-system unique value used by libs
		 * uint16_t  nttGran	- NTT granularity (1-32; 0=no NTT)
		 * uint32_t  numNtt	- number of NTT entries
		 * uint32_t  hugeTLBPS	- MRT huge page size (KB)
		 */
		printf("resId=%llu  %8s %8s, apid=%-10llu pagg=%-6llu PEs=%d, nodes=%d ",
			(unsigned long long)ai_info->resId,
			pass  ? pass->pw_name  : "?",
			group ? group->gr_name : "?",
			(unsigned long long)ai_info->apid,
			(unsigned long long)ai_info->pagg,
			ai_info->numPlaces,
			ai_info->numCmds
		);

		offset += sizeof(appInfo_t);
		/*
		 * If aprunPid is 0, nothing is running at the moment
		 * On the XT, if pagg is 0 it means the 
		 */
		if (ai_info->aprunPid) {
			printf("aprun: nid%05u:%d ",
				ai_info->aprunNid, ai_info->aprunPid 
			);
		} else {
			printf("req=%3d  flags=%llu",
				ai_info->reqType,
				(unsigned long long)ai_info->flags
			);
		}
		printf("\n");
#include <time.h>
		//printf("  Created at Thu Feb 17 16:09:47 2011"
		printf("  Created at %d\n", ai_hdr->created);
		//printf("  Created at %d\n", ai_info->timeLim +3);
		//printf("  Created at %s\n", ctime(&ai_info->timePlaced));
		printf("  Number of commands %d, control network fanout %d\n",
				ai_info->numCmds, ai_info->fanout);

		if (ai_info->pagg != 0) {
			ptr = ai_buf + ai_info->cmdDetail;
			for (j = 0; j < ai_info->numCmds; j++) {
				cmdDetail_t *det = (cmdDetail_t *)ptr;

				printf("  Cmd[%d]: BASIL -n %d", j, det->width);
				if (det->depth != 1)
					printf(" -d %d", det->depth);
				if (det->fixedPerNode)
					printf(" -N %d", det->fixedPerNode);
				if (ai_info->aprunPid)
					printf(" %s", det->cmd);
				printf(", %dMB, %s, nodes %d\n", det->memory,
					_alps_arch(det->arch), det->nodeCnt);
				ptr += sizeof(cmdDetail_t);
			}
			ptr = ai_buf + ai_info->places;
			for (j = 0; j < ai_info->numPlaces; j++) {
				placeList_t *entry = (placeList_t *)ptr;

				if (ns_add_node(&ns, entry->nid))
					fatal("can not add node to list");
				ptr += sizeof(placeList_t);
			}
			printf("  Reservation list entries: %d\n", ns_count_nodes(ns));
			printf("  Reservation list: %s\n", ns_to_string(ns));
		}
		printf("\n");

		/* 
		 * Compute the dependent offsets 
		 */
		offset += ai_info->numCmds   * sizeof(cmdDetail_t);
		offset += ai_info->numPlaces * sizeof(placeList_t);
		free_nodespec(ns);
	}
}

int main(int argc, char **argv)
{
	uint8_t	*ai_buf = basil_get_appinfo();

	print_apstat(ai_buf);
	free(ai_buf);

//	basil_get_apids_for_resid(0);
	return EXIT_SUCCESS;
}
