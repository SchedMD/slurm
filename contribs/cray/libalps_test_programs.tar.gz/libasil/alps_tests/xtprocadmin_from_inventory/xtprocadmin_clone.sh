#!/bin/bash
#
# Sort the output of the INVENTORY response, since it is unordered.
#
$(dirname $(readlink -f $0))/inventory_based_xtprocadmin | sort -n
